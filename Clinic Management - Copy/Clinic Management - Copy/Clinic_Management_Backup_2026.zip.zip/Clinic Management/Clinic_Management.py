from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import sqlite3

app = Flask(__name__)
app.config['SECRET_KEY'] = 'clinic_management_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///clinic.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# --- Database Models ---
class User(db.Model):
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)

class Patient(db.Model):
    patient_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), nullable=True)
    patient_code = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    birth_date = db.Column(db.String(20))
    sex = db.Column(db.String(10))
    contact_number = db.Column(db.String(20))
    address = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    appointments = db.relationship('Appointment', backref='patient', lazy=True)

class Doctor(db.Model):
    doctor_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'), unique=True)
    doctor_code = db.Column(db.String(20), unique=True)
    doctor_name = db.Column(db.String(100))
    specialization = db.Column(db.String(100))
    appointments = db.relationship('Appointment', backref='doctor', lazy=True)

class Appointment(db.Model):
    appointment_id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.patient_id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.doctor_id'), nullable=False)
    appointment_date = db.Column(db.String(50), nullable=False)
    reason = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), default='Pending')

# --- Auto DB Migration Helper ---
def patch_patient_table():
    db_path = os.path.join(app.instance_path, 'clinic.db') if os.path.exists(os.path.join(app.instance_path, 'clinic.db')) else 'clinic.db'
    if os.path.exists(db_path):
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(patient)")
        columns = [column[1] for column in cursor.fetchall()]
        
        missing_cols = {
            'birth_date': "VARCHAR(20)",
            'sex': "VARCHAR(10)",
            'address': "VARCHAR(255)",
            'is_active': "BOOLEAN DEFAULT 1"
        }
        for col, col_type in missing_cols.items():
            if col not in columns:
                cursor.execute(f"ALTER TABLE patient ADD COLUMN {col} {col_type}")
        conn.commit()
        conn.close()

# --- Initialize Database ---
with app.app_context():
    db.create_all()
    patch_patient_table()
    if not User.query.filter_by(role='admin').first():
        admin_user = User(
            username='admin',
            email='admin@clinic.com',
            password_hash=generate_password_hash('admin123', method='pbkdf2:sha256'),
            role='admin'
        )
        db.session.add(admin_user)
        db.session.commit()

# --- Auth Routes ---
@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for(f"dashboard_{session['role']}"))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identifier = request.form['identifier']
        password = request.form['password']
        user = User.query.filter((User.username == identifier) | (User.email == identifier)).first()

        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.user_id
            session['username'] = user.username
            session['role'] = user.role
            return redirect(url_for(f"dashboard_{user.role}"))
        else:
            flash("Invalid credentials!", "danger")
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role', 'patient')
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or Email is already registered.", "danger")
            return redirect(url_for('register'))

        hashed_pw = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password_hash=hashed_pw, role=role)
        db.session.add(new_user)
        db.session.commit()

        if role == 'patient':
            new_patient = Patient(
                user_id=new_user.user_id,
                patient_code=f"P-{new_user.user_id:04d}",
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                birth_date=request.form.get('birth_date', ''),
                sex=request.form.get('sex', ''),
                contact_number=request.form.get('contact', ''),
                address=request.form.get('address', ''),
                is_active=True
            )
            db.session.add(new_patient)
        elif role == 'doctor':
            new_doctor = Doctor(
                user_id=new_user.user_id,
                doctor_code=f"DOC-{new_user.user_id:03d}",
                doctor_name=request.form.get('doctor_name', ''),
                specialization=request.form.get('specialization', '')
            )
            db.session.add(new_doctor)

        db.session.commit()
        flash("Registration successful! You may now log in.", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

# --- Admin Dashboard & Patient Management ---
@app.route('/dashboard/admin', methods=['GET'])
def dashboard_admin():
    if session.get('role') != 'admin':
        flash("Access restricted to administrators.", "danger")
        return redirect(url_for('login'))

    search_query = request.args.get('search', '').strip()

    if search_query:
        patients = Patient.query.filter(
            (Patient.patient_code.ilike(f"%{search_query}%")) |
            (Patient.first_name.ilike(f"%{search_query}%")) |
            (Patient.last_name.ilike(f"%{search_query}%"))
        ).all()
    else:
        patients = Patient.query.all()

    last_patient = Patient.query.order_by(Patient.patient_id.desc()).first()
    next_id = (last_patient.patient_id + 1) if last_patient else 1
    default_code = f"P-{next_id:04d}"

    return render_template('dashboard_admin.html', patients=patients, default_code=default_code, search_query=search_query)

# --- Patient Actions ---
@app.route('/patient/add', methods=['POST'])
def add_patient():
    if session.get('role') not in ['admin', 'doctor']:
        return redirect(url_for('login'))

    patient_code = request.form['patient_code']
    if Patient.query.filter_by(patient_code=patient_code).first():
        flash("Patient ID already exists!", "danger")
        return redirect(url_for('dashboard_admin'))

    new_patient = Patient(
        patient_code=patient_code,
        first_name=request.form['first_name'],
        last_name=request.form['last_name'],
        birth_date=request.form['birth_date'],
        sex=request.form['sex'],
        contact_number=request.form['contact_number'],
        address=request.form['address'],
        is_active=True
    )

    db.session.add(new_patient)
    db.session.commit()
    flash("Patient registered successfully!", "success")
    return redirect(url_for('dashboard_admin'))

@app.route('/patient/edit/<int:id>', methods=['POST'])
def edit_patient(id):
    if session.get('role') not in ['admin', 'doctor']:
        return redirect(url_for('login'))
    
    patient = Patient.query.get_or_404(id)
    patient.first_name = request.form['first_name']
    patient.last_name = request.form['last_name']
    patient.birth_date = request.form['birth_date']
    patient.sex = request.form['sex']
    patient.contact_number = request.form['contact_number']
    patient.address = request.form['address']
    
    db.session.commit()
    flash("Patient record updated!", "success")
    return redirect(url_for('dashboard_admin'))

@app.route('/patient/toggle_status/<int:id>')
def toggle_patient_status(id):
    if session.get('role') not in ['admin', 'doctor']:
        return redirect(url_for('login'))
    
    patient = Patient.query.get_or_404(id)
    patient.is_active = not patient.is_active
    db.session.commit()
    
    status_msg = "activated" if patient.is_active else "deactivated"
    flash(f"Patient {patient.patient_code} has been {status_msg}.", "warning")
    return redirect(url_for('dashboard_admin'))

# --- Other Dashboards & System Routes ---
@app.route('/patients', methods=['GET'])
def patient_management():
    return redirect(url_for('dashboard_admin'))

@app.route('/dashboard/doctor')
def dashboard_doctor():
    if session.get('role') != 'doctor':
        return redirect(url_for('login'))
    doctor = Doctor.query.filter_by(user_id=session['user_id']).first()
    appointments = Appointment.query.filter_by(doctor_id=doctor.doctor_id).all() if doctor else []
    return render_template('dashboard_doctor.html', doctor=doctor, appointments=appointments)

@app.route('/dashboard/patient')
def dashboard_patient():
    if session.get('role') != 'patient':
        return redirect(url_for('login'))
    patient = Patient.query.filter_by(user_id=session['user_id']).first()
    doctors = Doctor.query.all()
    appointments = Appointment.query.filter_by(patient_id=patient.patient_id).all() if patient else []
    return render_template('dashboard_patient.html', patient=patient, doctors=doctors, appointments=appointments)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)